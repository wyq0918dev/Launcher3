package com.android.launcher3;

import android.content.ComponentName;
import android.content.Intent;

import androidx.appcompat.app.AppCompatActivity;

import com.android.bootlauncher.R;

public class LauncherActivity extends AppCompatActivity {

    @Override
    public void onResume() {
        String pkg = getString(R.string.package_name);
        String cls = getString(R.string.launcher);
        Intent intent = new Intent(Intent.ACTION_MAIN);
        intent.addCategory(Intent.CATEGORY_LAUNCHER);
        ComponentName cn = new ComponentName(pkg, cls);
        intent.setComponent(cn);
        startActivity(intent);
        super.onResume();
    }
}